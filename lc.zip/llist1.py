#!/usr/bin/python

class LNode():
    def __init__(self,val):
        self.val = val
        self.next = None

class LList():
    def __init__(self):
        self.head = None

    def traverse():
        if not self.head:
            print "Empty List"
        p = self.head
        while p.next:
            print p.val,
            p = p.next

        print ''

    def append(val):
        pass

    def insert(index,val):
        pass

    def get_count():
        pass
