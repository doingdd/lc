#!/usr/bin/python
import threading

def show(s,_acquire,_release):
    
    print 
