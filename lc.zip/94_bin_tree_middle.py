#!/usr/bin/python
import math

def traverse(root):
    n = math.log(len(root)+1,2)
    print n
    pass


root = [1,None,2,3]
print traverse(root)
